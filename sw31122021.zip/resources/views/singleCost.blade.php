@extends('main-layout')
@section('title')
    Cost | Simple Wallet App
@endsection

@section('main-content')
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App | Ваш расход</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>
    <div class="container">
        <br>
        <p><i>Редактирование расходов подъедет в следующей версии. А сейчас пока что можно удалить неправильный расход и заново добавить верный.</i></p>
        <div class="alert alert-success">
            <div>Категория: {{ $cost->category->name }}</div>
            <div>Кошелек: {{ $cost->wallet->name }}</div>
            <div>Сумма: <b>{{ $cost->value }} руб.</b></div>
            <div>Дата: {{ $cost->created_at }}</div>
            <div>Комментарий: {{ $cost->comment }}</div>
        </div>
        <div class="row col-12">
            <div class="col-4">
            <a class="btn btn-primary btn-sm" href="{{ route('costs') }}">Вернуться</a>
            </div>

            <div class="form-group col-4">
                {{ Form::submit('Изменить', ['class' => 'btn btn-secondary btn-sm', 'disabled' => 'disabled']) }}
            </div>

            <div class="form-group col-4">
            @if($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach($errors->all() as $error)
                            <li>{{ $error }} </li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('deleted', $cost->id) }}" method="post">
                @csrf
                {{ Form::submit('Удалить', ['class' => 'btn btn-danger btn-sm']) }}
            </form>
            </div>
        </div>
    </div>
@endsection
@section('scripts')

@endsection
