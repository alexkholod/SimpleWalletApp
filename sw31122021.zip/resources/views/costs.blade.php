@extends('main-layout')
@section('title')
    Costs | Simple Wallet App
@endsection

@section('main-content')
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App | Расходы</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>

    <div class="container" style="margin-bottom: 80px">
    <br>

            <div class="form-group col-12">
                @if($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach($errors->all() as $error)
                                <li>{{ $error }} </li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('costsPerMonth', $selectedYear, $selectedMonth) }}" method="post">
                    @csrf
                    <div class="form-group">
                        <label for="year"></label>
                        {{ Form::select('year', $year, ['class' => 'form-control']) }}

                        <label for="month"></label>
                        {{ Form::select('month', $month, ['class' => 'form-control']) }}

                        {{ Form::submit('Выбрать', ['class' => 'btn btn-success btn-sm']) }}
                    </div>
                </form>
            </div>

        <div class="row alert alert-success">

            <b>Расходы за {{ $selectedMonth }} месяц {{ $selectedYear }} года: {{ $sum }} руб.</b>
            @foreach($costsByCategory as $key => $value)
                @if ($value != 0)
                    <div class="col-7">{{ $key }}</div>
                    <div class="col-5">{{ $value }} руб.</div>
                @endif
            @endforeach
        </div>

        @foreach($data as $element)
            <a href="{{ route('single', $element->id) }}">
                <div class="row alert alert-success">
                    <div class="col-6">{{ $element->category->name }}</div>
                    <div class="col-2">{{ $element->wallet->name }}</div>
                    <div class="col-4"><b>{{ $element->value }}</b> руб.</div>
                    <div class="col-4">{{ $element->created_at->format('d.m.Y') }}</div>
                    <div class="col-8">{{ $element->comment }}</div>
                </div>
            </a>
        @endforeach
    </div>
@endsection
