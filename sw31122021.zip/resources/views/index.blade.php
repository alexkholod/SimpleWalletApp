@extends('main-layout')
@section('title')
    Simple Wallet App
@endsection

@section('main-content')
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>
    <div class="container">
        <br>
        <div class="row alert alert-success">
            <div class="col-7">На этой неделе</div>
            <div class="col-5"><b>{{ $week }}</b> руб.</div>
        </div>

        <div class="row alert alert-success">
            <div class="col-7">В этом месяце</div>
            <div class="col-5"><b>{{ $month }}</b> руб.</div>
        </div>

        <div class="row alert alert-success">
            <div class="col-10"><p>ТОП-5 категорий расходов:</p></div>
            @foreach($costsByCategory as $key => $value)
                <div class="col-7">{{ $key }}</div>
                <div class="col-5">{{ $value }} руб.</div>
            @endforeach
        </div>

        <p><a class="btn btn-success btn-sm" href="{{ route('add-cost') }}">Добавить расход</a></p>
    </div>
@endsection


