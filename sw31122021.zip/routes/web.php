<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::middleware('auth')->group(function () {

    Route::get('/', 'CostController@makeMainView')
        ->name('home');

    Route::get('/add-cost', 'CostController@makeAddView')
        ->name('add-cost');

    Route::post('/add-cost/added', 'CostController@add')
        ->name('added');

    Route::get('/cost/{id}', 'CostController@viewSingleCost')
        ->name('single');

    Route::post('/costsPerMonth', 'CostController@makeAllCostsView')
        ->name('costsPerMonth');

    Route::get('/costs', 'CostController@makeAllCostsView')
        ->name('costs');

    Route::post('/delete-cost/deleted/{id}', 'CostController@delete')
        ->name('deleted');

    Route::get('/settings/wallets', 'WalletController@allWallets')
        ->name('wallets');

    Route::get('/settings/categories', 'CategoryController@allCategories')
        ->name('categories');

    Route::get('/settings', function () {
        return view('settings');
    })->name('settings');
});

Route::middleware('guest')->group(function (){
});

