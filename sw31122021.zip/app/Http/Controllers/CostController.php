<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddCostRequest;
use App\Models\Category;
use App\Models\Cost;
use App\Models\Wallet;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class CostController extends Controller
{


    public function add(AddCostRequest $request): RedirectResponse
    {
        $cost = new Cost();
        $cost->user_id = $request->user()->id;
        $cost->wallet_id = $request->input('wallets');
        $cost->category_id = $request->input('categories');
        $cost->value = $request->input('value');
        $cost->comment = $request->input('comment');

        $cost->save();

        return redirect()->route('costs');
    }

    public function makeAllCostsView(Carbon $period, Request $request)
    {
        $year = [
            2021 => '2021',
            2022 => '2022',
            2023 => '2023'
        ];

        $month = [
            1 => 'Январь',
            2 => 'Февраль',
            3 => 'Март',
            4 => 'Апрель',
            5 => 'Май',
            6 => 'Июнь',
            7 => 'Июль',
            8 => 'Август',
            9 => 'Сентябрь',
            10 => 'Октябрь',
            11 => 'Ноябрь',
            12 => 'Декабрь'
        ];

        if ($request->year == null) {
            $selectedYear = Carbon::now()->year;
            $selectedMonth = Carbon::now()->month;
        } else {
            $selectedYear = $request->year;
            $selectedMonth = $request->month;
        }

        $allCostsPerMonth = $this->costsPerMonth($selectedYear, $selectedMonth, $period, $request);

        $sum = $allCostsPerMonth->sum('value');

        $costsByCategory = $this->costsByCategory($selectedYear, $selectedMonth, $period, $request);

        return view('costs', [
            'data' => $allCostsPerMonth,
            'sum' => $sum,
            'year' => $year,
            'month' => $month,
            'selectedYear' => $selectedYear,
            'selectedMonth' => $selectedMonth,
            'costsByCategory' => $costsByCategory
        ]);
    }

    public function costsPerMonth(int $year, int $month, Carbon $period, Request $request)
    {
        $costsPerMonth = Cost::all()
            ->where('user_id', '=', $request->user()->id)
            ->whereBetween('created_at', [
            $period->createFromDate($year, $month)->startOfMonth(),
            $period->createFromDate($year, $month)->endOfMonth()
        ])->sortByDesc('created_at');

        return $costsPerMonth;
    }

    public function costsByCategory(int $year, int $month, Carbon $period, Request $request)
    {
        $categories = Category::all();

        $costsByCategory = [];

        foreach ($categories as $category) {
            $costsByCategory[$category->name] = Cost::where('user_id', '=', $request->user()->id)
            ->where('category_id', '=', $category->id)
                ->whereBetween('created_at', [
                    $period->createFromDate($year, $month)->startOfMonth(),
                    $period->createFromDate($year, $month)->endOfMonth()
                ])->sum('value');
        }
        arsort($costsByCategory);
        return $costsByCategory;
    }

    public function makeMainView(Request $request)
    {
        $costPerWeek = Cost::where('user_id', '=', $request->user()->id)
        ->whereBetween('created_at', [
            Carbon::parse('last monday'),
            Carbon::now()->endOfWeek()
        ])->sum('value');

        $costPerMonth = Cost::where('user_id', '=', $request->user()->id)
        ->whereBetween('created_at', [
            Carbon::now()->startOfMonth(),
            Carbon::now()->endOfMonth()
        ])->sum('value');

        $categories = Category::all();

        $costsByCategory = [];

        foreach ($categories as $category) {
            $costsByCategory[$category->name] = Cost::where('user_id', '=', $request->user()->id)
            ->where('category_id', '=', $category->id)
            ->whereBetween('created_at', [
                      Carbon::now()->startOfMonth(),
                      Carbon::now()->endOfMonth()
                 ])->sum('value');
        }

        arsort($costsByCategory);
        $costsByCategory = array_slice($costsByCategory, 0, 5, true);

        return view('index', [
            'week'  => $costPerWeek,
            'month' => $costPerMonth,
            'costsByCategory' => $costsByCategory
        ]);
    }

    public function makeAddView()
    {
        $wallets = Wallet::pluck('name', 'id');
        $categories = Category::pluck('name', 'id');

        return view('addCost')
            ->with(compact('wallets', 'categories' ));
    }

    public function viewSingleCost($id)
    {
        $cost = Cost::find($id);

        return view('singleCost', ['cost' => $cost]);
    }

    public function delete($id)
    {
        $cost = Cost::find($id);
        $cost->category()->dissociate();
        $cost->wallet()->dissociate();
        $cost->delete();

        return redirect()->route('costs');
    }
}
