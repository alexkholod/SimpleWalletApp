<?php $__env->startSection('title'); ?>
    Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>
    <div class="container">
        <div class="row justify-content-center" style="margin-top: 15px">






















































        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        </div>
    </div>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/layouts/app.blade.php ENDPATH**/ ?>