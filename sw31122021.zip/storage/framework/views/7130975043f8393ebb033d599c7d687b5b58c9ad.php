<?php $__env->startSection('title'); ?>
    Add Cost | Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <div class="row col-md 12">
            <h5>Легкий учет ваших финансов</h5>

            <h4>Расход добавлен</h4>
        </div>
            <a class="btn btn-success" href="<?php echo e(route('add-cost')); ?>">Добавить еще</a>
            <a class="btn btn-primary" href="<?php echo e(route('home')); ?>">На главную</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/added.blade.php ENDPATH**/ ?>