<?php $__env->startSection('title'); ?>
    Authorize | Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App | Авторизация</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>
    <div class="container">
        <form class="col-12">
            <br>
            <h3>Вход</h3>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('login_process')); ?>" method="post">
                <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="email">E-mail</label>
                <?php echo e(Form::text('email','', ['class' => 'form-control'])); ?>

            </div>

            <div class="form-group">
                <label for="value">Password</label>
                <?php echo e(Form::text('password','', ['class' => 'form-control'])); ?>

            </div>
            <div class="form-group">
                <a href="" class="font-medium text-blue-900 hover:bg-blue-300 rounded-md p-2">Забыли пароль?</a>
                |
                <a href="<?php echo e(route('register')); ?>" class="font-medium text-blue-900 hover:bg-blue-300 rounded-md p-2">Регистрация</a>
            </div>

            <div class="form-group">
                <?php echo e(Form::submit('Войти', ['class' => 'btn btn-success'])); ?>

            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/login.blade.php ENDPATH**/ ?>