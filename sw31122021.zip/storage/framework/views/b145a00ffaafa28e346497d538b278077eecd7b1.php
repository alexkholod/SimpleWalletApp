<?php $__env->startSection('title'); ?>
    Settings | Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <div class="row col-md 12">
            <h5>Легкий учет ваших финансов</h5>

            <h4>Настройки</h4>
        </div>

        <a class="btn btn-primary" href="<?php echo e(route('home')); ?>">На главную</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/settings.blade.php ENDPATH**/ ?>