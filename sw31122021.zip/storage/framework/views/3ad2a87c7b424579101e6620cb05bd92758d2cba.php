<?php $__env->startSection('title'); ?>
    Add Cost | Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App | Ввод расхода</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>
    <div class="container">
        <br>
        <div class="form-group col-10">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?> </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('added')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="wallets">Кошелек</label>
                <?php echo e(Form::select('wallets', $wallets, ['class' => 'form-control'])); ?>

            </div>

            <div class="form-group">
                <label for="categories">Категория</label>
                <?php echo e(Form::select('categories', $categories, ['class' => 'form-control'])); ?>

            </div>

            <div class="form-group">
                <label for="value">Сумма, руб.</label>
                <?php echo e(Form::text('value','', ['class' => 'form-control'])); ?>

            </div>

            <div class="form-group">
                <label for="comment">Комментарий</label>
                <?php echo e(Form::text('comment','', ['class' => 'form-control'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::submit('Сохранить', ['class' => 'btn btn-success btn-sm'])); ?>

            </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/addCost.blade.php ENDPATH**/ ?>