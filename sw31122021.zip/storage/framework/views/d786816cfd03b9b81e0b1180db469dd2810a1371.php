<?php $__env->startSection('title'); ?>
    Authorize | Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App | Регистрация</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>
    <div class="container">
    <div class="row justify-content-center" style="margin-top: 15px">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <p>Извини, дорогой, но регистрацияя сейчас ограничена</p>
                    <p>Потыкать кнопки можно с тестовыми данными:</p>
                    <p>test@test.test</p>
                    <p>testtest</p>
                    <div class="col-md-6 offset-md-4">
                        <a class="btn btn-primary" href="<?php echo e(route('login')); ?>" >Ок, попробую</a>
                    </div>
                </div>
            </div>






































































        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/auth/register.blade.php ENDPATH**/ ?>