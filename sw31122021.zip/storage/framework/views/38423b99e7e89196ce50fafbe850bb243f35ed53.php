<?php $__env->startSection('title'); ?>
    Costs | Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App | Кошельки</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>
    <div class="container">
    <br>
        <p><i>Редактирование и добавление кошельков подъедет в следующей версии</i></p>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('single', $element->id)); ?>">
                <div class="row alert alert-success">
                    <div class="col-4"><b><?php echo e($element->name); ?></b></div>
                    <div class="col-8"><?php echo e($element->description); ?></div>
                </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/wallets.blade.php ENDPATH**/ ?>