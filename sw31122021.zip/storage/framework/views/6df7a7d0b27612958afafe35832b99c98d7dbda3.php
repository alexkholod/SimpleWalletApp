<?php $__env->startSection('title'); ?>
    Costs | Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App | Расходы</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>

    <div class="container" style="margin-bottom: 80px">
    <br>

            <div class="form-group col-12">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?> </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('costsPerMonth', $selectedYear, $selectedMonth)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="year"></label>
                        <?php echo e(Form::select('year', $year, ['class' => 'form-control'])); ?>


                        <label for="month"></label>
                        <?php echo e(Form::select('month', $month, ['class' => 'form-control'])); ?>


                        <?php echo e(Form::submit('Выбрать', ['class' => 'btn btn-success btn-sm'])); ?>

                    </div>
                </form>
            </div>

        <div class="row alert alert-success">

            <b>Расходы за <?php echo e($selectedMonth); ?> месяц <?php echo e($selectedYear); ?> года: <?php echo e($sum); ?> руб.</b>
            <?php $__currentLoopData = $costsByCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($value != 0): ?>
                    <div class="col-7"><?php echo e($key); ?></div>
                    <div class="col-5"><?php echo e($value); ?> руб.</div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('single', $element->id)); ?>">
                <div class="row alert alert-success">
                    <div class="col-6"><?php echo e($element->category->name); ?></div>
                    <div class="col-2"><?php echo e($element->wallet->name); ?></div>
                    <div class="col-4"><b><?php echo e($element->value); ?></b> руб.</div>
                    <div class="col-4"><?php echo e($element->created_at->format('d.m.Y')); ?></div>
                    <div class="col-8"><?php echo e($element->comment); ?></div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/costs.blade.php ENDPATH**/ ?>