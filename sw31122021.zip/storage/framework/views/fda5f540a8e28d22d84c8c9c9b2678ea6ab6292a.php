<?php $__env->startSection('title'); ?>
    Settings | Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App | Настройки</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>
    <div class="container">
            <br>
            <p><i>Полный функционал этого раздела подъедет в следующей версии</i></p>
            <div class="row alert alert-success">
                <div class="col-10">Профиль</div>
            </div>

            <a href="<?php echo e(route('wallets')); ?>">
            <div class="row alert alert-success">
                <div class="col-10">Кошельки</div>
            </div>
            </a>

            <a href="<?php echo e(route('categories')); ?>">
            <div class="row alert alert-success">
                <div class="col-10">Категории расходов</div>
            </div>
            </a>

        <div class="row alert alert-success">
            <div class="col-10">Источники доходов</div>
        </div>

        <div class="row alert alert-success">
            <div class="col-10">О программе</div>
        </div>

        <?php if(auth()->guard('web')->check()): ?>
        <div class="row alert alert-success">
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                <?php echo e(__('Выйти')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/settings.blade.php ENDPATH**/ ?>