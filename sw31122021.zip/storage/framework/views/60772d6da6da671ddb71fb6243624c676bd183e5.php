<?php $__env->startSection('title'); ?>
    Cost | Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App | Ваш расход</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>
    <div class="container">
        <br>
        <p><i>Редактирование расходов подъедет в следующей версии. А сейчас пока что можно удалить неправильный расход и заново добавить верный.</i></p>
        <div class="alert alert-success">
            <div>Категория: <?php echo e($cost->category->name); ?></div>
            <div>Кошелек: <?php echo e($cost->wallet->name); ?></div>
            <div>Сумма: <b><?php echo e($cost->value); ?> руб.</b></div>
            <div>Дата: <?php echo e($cost->created_at); ?></div>
            <div>Комментарий: <?php echo e($cost->comment); ?></div>
        </div>
        <div class="row col-12">
            <div class="col-4">
            <a class="btn btn-primary btn-sm" href="<?php echo e(route('costs')); ?>">Вернуться</a>
            </div>

            <div class="form-group col-4">
                <?php echo e(Form::submit('Изменить', ['class' => 'btn btn-secondary btn-sm', 'disabled' => 'disabled'])); ?>

            </div>

            <div class="form-group col-4">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('deleted', $cost->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(Form::submit('Удалить', ['class' => 'btn btn-danger btn-sm'])); ?>

            </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/singleCost.blade.php ENDPATH**/ ?>