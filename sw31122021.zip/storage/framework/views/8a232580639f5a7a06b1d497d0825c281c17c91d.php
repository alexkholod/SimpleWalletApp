<?php $__env->startSection('title'); ?>
    Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <div class="row col-md 12">
            <h1>Simple Wallet App</h1>
            <h4>Легкий учет ваших финансов</h4>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/index.blade.php ENDPATH**/ ?>
