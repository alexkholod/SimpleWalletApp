<?php $__env->startSection('title'); ?>
    Add Cost | Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <div class="row col-md 12">
            <h5>Легкий учет ваших финансов</h5>

            <h4>Добавить расход</h2>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?> </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('added')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="wallet">Кошелек</label>
                <input type="text" name="wallet" id="wallet" class="form-control">
            </div>

            <div class="form-group">
                <label for="category">Категория</label>
                <input type="text" name="category" id="category" class="form-control">
            </div>

            <div class="form-group">
                <label for="value">Сумма</label>
                <input type="text" name="value" id="value" placeholder="Введите сумму" class="form-control">
            </div>

            <div class="form-group">
                <label for="comment">Комментарий</label>
                <input type="text" name="comment" id="comment" class="form-control">
            </div>

             <button type="submit" class="btn btn-success">Сохранить</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/addCost.blade.php ENDPATH**/ ?>