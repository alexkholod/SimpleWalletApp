<?php $__env->startSection('title'); ?>
    Simple Wallet App
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #25CDA5;">
        <div class="navbar-brand">Simple Wallet App</div>
        <div class="navbar-text">Легкий учет ваших финансов</div>
    </nav>
    <div class="container">
        <br>
        <div class="row alert alert-success">
            <div class="col-7">На этой неделе</div>
            <div class="col-5"><b><?php echo e($week); ?></b> руб.</div>
        </div>

        <div class="row alert alert-success">
            <div class="col-7">В этом месяце</div>
            <div class="col-5"><b><?php echo e($month); ?></b> руб.</div>
        </div>

        <div class="row alert alert-success">
            <div class="col-10"><p>ТОП-5 категорий расходов:</p></div>
            <?php $__currentLoopData = $costsByCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-7"><?php echo e($key); ?></div>
                <div class="col-5"><?php echo e($value); ?> руб.</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <p><a class="btn btn-success btn-sm" href="<?php echo e(route('add-cost')); ?>">Добавить расход</a></p>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/index.blade.php ENDPATH**/ ?>